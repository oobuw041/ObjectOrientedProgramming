public interface Rewards{
	boolean awards();
  
}