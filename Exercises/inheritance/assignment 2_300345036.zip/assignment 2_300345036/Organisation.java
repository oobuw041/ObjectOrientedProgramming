public interface Organisation{
	String name();
	String category();
}